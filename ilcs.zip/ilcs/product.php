<?php require_once("header.php") ?>
	<!-- mobile_botton -->
	<button type="button" id="mobile-nav-toggle">
		<i class="fa fa-bars fa-2x" id="menu-icon"></i>
	</button>

	<!-- header_nav_bar -->
	<header class="header-fixed" id="headerProduct">
		<div class="container-fluid" id="containerProduct">
			<div class="container-fluid">
				<div class="pull-left" id="logo" style="clear:left; display:inline-block; background-color:transparent;">
					<h1>
						<img src="img/logo.png" width="40px;">
						<a href="#" class="scrollto" id="text-logo">ILCS Training</a>
					</h1>
				</div>
				<nav id="nav-menu-container">
					<ul class="nav-menu sf-js-enabled sf-arraows" style="touch-action:pan-y;">
						<li>
							<a href="./#about">About Us</a>
						</li>
						<li>
							<a href="#">Available Workshops</a>
						</li>
						<li>
							<a href="">Blog</a>
							</li>
						<li>
							<a href="" class="btn btn-outline-primary btn-round p-0 px-3" style="max-width:100px; border:1px solid white;">Register</a>
						</li>
						<li>
							<a href="" class="btn btn-outline-secondary btn-round p-0 px-3" style="max-width:100px; border:1px solid white;">Login</a>
						</li>
					</ul>
				</nav>
			</div>
		</div>
	</header>

<div id="main">
	<div class="container" id="contProduct">
		<div class="row justify-content-md-center">
			<div class="col-md-8 col-lg-6 mt-5">
				<form action="#" accept-charset="utf-8" method="get">
					<input name="utf-8" type="hidden" value=""></input>
					<div class="input-group">
						<input class="form-control" name="keyword" placeholder="Cari" type="text"></input>
						<div class="input-group-append">
							<button class="btn btn-outline-primary" id="button-addon2">
								<i class="fa fa-search"></i>
							</button>
						</div>
					</div>
				</form>
				<div class="d-flex flex-wrap justify-content-center sm-1" id="catProduct">
					<div class="p-2">
						<a href="/product?category=0"> Semua Kategory</a>
					</div>
					<div class="p-2">
						<a href="/product?category=1"> IT/Komputer</a>
					</div>
					<div class="p-2">
						<a href="/product?category=2"> Kuliner</a>
					</div>
					<div class="p-2">
						<a href="/product?category=11"> Robotika</a>
					</div>
					<div class="p-2">
						<a href="/product?category=12"> Marketing</a>
					</div>
					<div class="p-2">
						<a href="/product?category=13"> Edukasi</a>
					</div>
					<div class="p-2">
						<a href="/product?category=14"> Masak</a>
					</div>
					<div class="p-2">
						<a href="/product?category=15"> Pareting</a>
					</div>
					<div class="p-2">
						<a href="/product?category=17"> Fotografi</a>
					</div>
					<div class="p-2">
						<a href="/product?category=18"> Enterpreneur</a>
					</div>
				</div>
			</div>
		</div>
		<hr>
		<div class="my-3 fg-gray-600">
			<small>61 kursus ditemukan</small>
		</div>
		<div class="row d-md-flex mt-4" id="prodResult">
			<div class="col-lg-4 col-md-4 mt-2">
				<a class="d-block" href="#">
					<div class="card card-outline-primary mb-5">
						<div class="card-img-top">
							<div class="rounded-circle text-center bg--primary fg--white">
								<div class="d-flex flex-column">
									<div class="bg-3">16</div>
									<div class="sm-3">NOV</div>
								</div>
							</div>
						</div>
						<div class="position-absolute fg--white">
							<b>33%</b>
						</div>
						<div class="card-body p-2 pt-3 mt-3">
							<div class="px-2">
								<h4 class="card-title text-primary">
									Sociopreneur Talk
								</h4>
								<div class="card-text text-muted pb-3 border-bottom"></div>
								<div class="text-center fg--gray pt-3 sm-2 mt-3">
									<del>Rp75000</del>
								</div>
								<div class="text-center card-title c-orange">
									<b>Rp50000</b>
								</div>
							</div>
						</div>
					</div>
				</a>
			</div>
			<div class="col-lg-4 col-md-4 mt-2">
				<a class="d-block" href="#">
					<div class="card card-outline-primary mb-5">
						<div class="card-img-top">
							<div class="rounded-circle text-center bg--primary fg--white">
								<div class="d-flex flex-column">
									<div class="bg-3">16</div>
									<div class="sm-3">NOV</div>
								</div>
							</div>
						</div>
						<div class="position-absolute fg--white">
							<b>33%</b>
						</div>
						<div class="card-body p-2 pt-3 mt-3">
							<div class="px-2">
								<h4 class="card-title text-primary">
									Sociopreneur Talk
								</h4>
								<div class="card-text text-muted pb-3 border-bottom"></div>
								<div class="text-center fg--gray pt-3 sm-2 mt-3">
									<del>Rp75000</del>
								</div>
								<div class="text-center card-title c-orange">
									<b>Rp50000</b>
								</div>
							</div>
						</div>
					</div>
				</a>
			</div>
			<div class="col-lg-4 col-md-4 mt-2">
				<a class="d-block" href="#">
					<div class="card card-outline-primary mb-5">
						<div class="card-img-top">
							<div class="rounded-circle text-center bg--primary fg--white">
								<div class="d-flex flex-column">
									<div class="bg-3">16</div>
									<div class="sm-3">NOV</div>
								</div>
							</div>
						</div>
						<div class="position-absolute fg--white">
							<b>33%</b>
						</div>
						<div class="card-body p-2 pt-3">
							<div class="px-2">
								<h4 class="card-title text-primary mt-3">
									Sociopreneur Talk
								</h4>
								<div class="card-text text-muted pb-3 border-bottom"></div>
								<div class="text-center fg--gray pt-3 sm-2 mt-3">
									<del>Rp75000</del>
								</div>
								<div class="text-center card-title c-orange">
									<b>Rp50000</b>
								</div>
							</div>
						</div>
					</div>
				</a>
			</div>
		</div>
	</div>
</div>


<?php require_once("footer.php"); ?>