<!DOCTYPE html>
<html>
<head>

	<meta charset="utf-8"></meta>
	<meta hhtp-equiv="X-UA-Compatibel" content="IE=edge">
	<meta name="view-port" content="width=device-width, initial-scale=1 shring-to-fit=no">
	<meta name="description" content="kursus,pelatihan">
	<meta name="author" content="ILCS">

	<title>ILCS-Kursus</title>

	<link rel="icon" type="img/icon" href="img/logo.png">

	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="bootstrap/fontawesome/css/all.min.css">

	<link rel="stylesheet" type="text/css" href="css/home.css">
	<link rel="stylesheet" type="text/css" href="css/product.css">
	<script type="text/javascript" src="js/jquery.js"></script>

</head>
<body id="body">

	<!-- mobile_side_menu -->
	<div class="nav" id='mobile-nav'>
		<div class="row" id="mobile-row-menu">
			<div class="col-8 col-sm-4 col-md-3 col-lg-3" id="mobile-menu">
				<nav id="nav-mobile-menu-container">
					<ul class="nav-menu sf-js-enabled sf-arraows" style="touch-action:pan-y;">
						<li>
							<a href="#about" class="mobile-menu">About Us</a>
						</li>
						<li>
							<a href="#product" class="mobile-menu">Available Workshops</a>
						</li>
						<li>
							<a href="" class="mobile-menu">Blog</a>
							</li>
						<li>
							<a href="" class="btn btn-outline-primary btn-round p-0 px-3" style="max-width:100px; border:1px solid white;">Register</a>
						</li>
						<li>
							<a href="" class="btn btn-outline-secondary btn-round p-0 px-3" style="max-width:100px; border:1px solid white;">Login</a>
						</li>
					</ul>
				</nav>
			</div>
		</div>
		<div class="col-12" id="mobile-cover"></div>
	</div>