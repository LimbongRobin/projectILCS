			<!-- contact -->
			<section id="contact">
				<div class="container">
					<div class="row">
						<div class="col-lg-4 col-md-6 pt-5">
							<div class="contact-about">
								<h3>Kursus Ku</h3>
								<p>Crafted with Love in Depok</p>
								<div class="social-links pb-0">
									<a class="facebook" href="">
										<i class="fa fa-facebook-official" aria-hidden="true"></i>
									</a>
									<a class="instagram" href="">
										<i class="fa fa-instagram"></i>
									</a>
									<a class="linkedin" href="">
										<i class="fa fa-linkedin"></i>
									</a>
								</div>
							</div>
						</div>
						<div class="col-lg-2 col-md-6 pt-5">
							<div class="fg--gray-600">
								Company
							</div>
							<div class="mt-3">
								<a href="#about">About Kursusku</a>
							</div>
							<div class="mt-3">
								<a href="#faq">FAQ</a>
							</div>
							<div class="mt-3">
								<a href="#blog">blog</a>
							</div>
						</div>
						<div class="col-lg-3 col-md-6 pt-5">
							<div class="fg--gray-600">
								HEADQUARTER
							</div>
							<div class="info mt-2">
								<i class="fa fa-map-marker fa-2x"></i>
								<p class="pb-2 pl-5">
									Tanjung Periok, Jakut.
								</p>
							</div>
							<div class="info mt-2">
								<i class="fa fa-envelope fa-2x"></i>
								<p class="pb-2 pl-5">
									ilcs@gmail.com
								</p>	
							</div>
							<div class="info mt-2">
								<i class="fa fa-comments fa-2x"></i>
								<p class="pb-2 pl-5">
									+62 853 7433 2207 (WA Only)
								</p>	
							</div>
						</div>
						<div class="col-lg-3 col-md-6 text-center pt-5">
							<div class="fg--gray-600" style="text-align:left;">
								Supported By:
							</div>
							<div class="mt-3">
								<div class="row">
									<div class="col-6">
										<img src="img/logo.png" id="logoContact"></img>	
									</div>
									<div class="col-6" style="text-align:left!important;">
										<p class="m-0"><b>I</b>ntegtrasi</p>	
										<p class="m-0"><b>L</b>ogistic</p>	
										<p class="m-0"><b>C</b>ipta</p>
										<p class="m-0"><b>S</b>olusi</p>		
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		</main>
	</div>
	<a class="back-to-top" href="#body">
		<i class="fa fa-chevron-up"></i>
	</a>
</body>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/_selfJs.js"></script>
<script type="text/javascript" src="js/jquery_ui/jquery-ui.min.js"></script>
</html>