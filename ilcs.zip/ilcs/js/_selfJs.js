
$(document).ready(function(){
	let width = $(window).width();
	let condition=0;

	if(condition == 0){
		if(width <= 768){
			$('#menu-icon').removeClass('fa-times').addClass('fa-bars');
		}
	}

	$(window).resize(function(){
		let width = $(window).width();
		if(width<=768){
			if(condition!=1){
				$('#menu-icon').removeClass('fa-times').addClass('fa-bars');
			}
			else{
				$('#menu-icon').removeClass('fa-bars').addClass('fa-times');
			}

		}
	});

	$('#menu-icon,#mobile-cover,.mobile-menu').on('click',function(){
		if(condition==0){
			$('#menu-icon').removeClass('fa-bars').addClass('fa-times');
			$('#mobile-nav').css({'display':'block'});
			$('#mobile-menu').show('slide',{
				direction:'left'
			},1000);
			condition=1;
		}

		else if(condition==1){
			$('#menu-icon').removeClass('fa-times').addClass('fa-bars');
			$('#mobile-menu').hide('slide',{
				direction:'left'
			},700);
			
			setTimeout(function() {
			$("#mobile-nav").css({'display':'none'});
			$('#mobile-nav').css({'display':'none'});
			 },700);	
			condition=0;			
		}
	});

	let heightWindow = $(window).height();
	let countData = 0;
	let count = 0;

	let data = Array();
	data = ["Belajar Parenting Di","Cari Kursus Masak Di","Belajar Ini Itu Di"];

	showTextAnimation();


	function showTextAnimation(){
		let i =0;
		let newData = data[count].split('');
		let setText = "";
		let status = "";
		let length = newData.length;

		setInterval(function(){
			if(count<length){
				status="Forward";
			}
			else{
				status="Backward";
			}
			text(newData,status,length);
			count++;
			if(count>=length*2){
				count=0;
				i++;
				if(i>=data.length-1){
					i=0;
				}
				newData = data[i].split('');
			}

		},500);

	}

	function text(newData,status,length){
		if(status == "Forward"){
			let setText = $('#animation').text();
			$('#animation').text(setText+newData[countData]);
			countData++;


		}
		else if(status == "Backward"){
			setText = $('#animation').text();
			setText = setText.substring(0,setText.length-1);

			$('#animation').text(setText);
			countData--;
		}


	}
	let zIndex=1;
	$(window).scroll(function(){
		let scrollTop = $(window).scrollTop();
		if(scrollTop>10){
			$('#container').css({'background-image':'linear-gradient(to right,#00FA9A,#33ad83,#76d2e1)'});	
			$('.back-to-top').css({'display':'block'});
		}
		else if(scrollTop<5){
			$('#container').css({'background-image':''});
			$('.back-to-top').css({
				transition:'opacity 4s easy-in-out',
				'display':'none'
			});
		}
	});

	let scrollTop = $(window).scrollTop();
	if(scrollTop>10){
		$('#container').css({'background-image':'linear-gradient(to right,#00FA9A,#33ad83,#76d2e1)'});
		$('.back-to-top').css({'display':'block'});	
	}
	else{
		$('#container').css({'background-image':''});	
		$('.back-to-top').css({
			transition:'opacity 4s easy-in-out',
			'display':'none'
		});
	}

	document.querySelectorAll('a[href^="#"]').forEach(anchor => {
	    anchor.addEventListener('click', function (e) {
	        e.preventDefault();
	        document.querySelector(this.getAttribute('href')).scrollIntoView({
	            behavior: 'smooth'
	        });
	    });
	});

});
